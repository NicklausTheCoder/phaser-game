# phaser-game
just a game dev project with phaser js
to run it cd into folder and npm run dev to start server